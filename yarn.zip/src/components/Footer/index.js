import './styles.css'

const Footer = () => {
    return(
        <footer>Produtos Folclóricos | Uma empresa do grupo Magazine Luzia | CNPJ: 99.999.999/9999-99</footer>
    );
}

export default Footer;